package org.momtsim.identity;

public class Properties {
    public static final String ID = "id";
    public static final String NAME = "name";
    public static final String PHONE = "phone";
    public static final String EMAIL = "email";
    public static final String SSN = "ssn";
    public static final String CCN = "ccn";
    public static final String HIGH_RISK = "highRisk";
}

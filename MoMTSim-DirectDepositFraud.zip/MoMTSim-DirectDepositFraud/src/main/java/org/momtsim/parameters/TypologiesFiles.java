package org.momtsim.parameters;

public class TypologiesFiles {
    public static final String drugNetworkOne = "DrugNetworkOne.graphml";
}
